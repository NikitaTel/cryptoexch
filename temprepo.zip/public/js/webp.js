// Support webp

var
   html = document.documentElement,
   WebP = new Image();
WebP.onload = WebP.onerror = function () {
   if (WebP.height === 2) {
      html.className += 'webp';
   }
};
WebP.src = 'data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAACyAgCdASoCAAIALmk0mk0iIiIiIgBoSygABc6WWgAA/veff/0PP8bA//LwYAAA';
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlcyI6WyJ3ZWJwLmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFN1cHBvcnQgd2VicFxuXG52YXJcbiAgIGh0bWwgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQsXG4gICBXZWJQID0gbmV3IEltYWdlKCk7XG5XZWJQLm9ubG9hZCA9IFdlYlAub25lcnJvciA9IGZ1bmN0aW9uICgpIHtcbiAgIGlmIChXZWJQLmhlaWdodCA9PT0gMikge1xuICAgICAgaHRtbC5jbGFzc05hbWUgKz0gJ3dlYnAnO1xuICAgfVxufTtcbldlYlAuc3JjID0gJ2RhdGE6aW1hZ2Uvd2VicDtiYXNlNjQsVWtsR1Jqb0FBQUJYUlVKUVZsQTRJQzRBQUFDeUFnQ2RBU29DQUFJQUxtazBtazBpSWlJaUlnQm9TeWdBQmM2V1dnQUEvdmVmZi8wUFA4YkEvL0x3WUFBQSc7Il0sImZpbGUiOiJ3ZWJwLmpzIn0=
