var
    doc = document,
    menu = doc.getElementsByClassName('burger')[0],
    lang_select = doc.getElementsByClassName('language-select')[0];

function menuToggle9() {
    menu.classList.toggle('open')}

function menuToggle() {
    lang_select.classList.toggle('open')}

function menuClose9() {
    menu.classList.remove('open');
}
function menuClose() {
    lang_select.classList.remove('open');
}
function menuCloseClickOutside9(e) {
    if(!e.target.matches('.burger *')){
        menuClose9();
    }
}
function menuCloseClickOutside(e) {
    if(!e.target.matches('.language-select *')){
        menuClose();
    }
}
doc.addEventListener('click', menuCloseClickOutside9);
doc.addEventListener('touchstart', menuCloseClickOutside9);
doc.addEventListener('click', menuCloseClickOutside);
doc.addEventListener('touchstart', menuCloseClickOutside);
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlcyI6WyI0MDQuanMiXSwic291cmNlc0NvbnRlbnQiOlsidmFyXG4gICAgZG9jID0gZG9jdW1lbnQsXG4gICAgbWVudSA9IGRvYy5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCdidXJnZXInKVswXSxcbiAgICBsYW5nX3NlbGVjdCA9IGRvYy5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCdsYW5ndWFnZS1zZWxlY3QnKVswXTtcblxuZnVuY3Rpb24gbWVudVRvZ2dsZTkoKSB7XG4gICAgbWVudS5jbGFzc0xpc3QudG9nZ2xlKCdvcGVuJyl9XG5cbmZ1bmN0aW9uIG1lbnVUb2dnbGUoKSB7XG4gICAgbGFuZ19zZWxlY3QuY2xhc3NMaXN0LnRvZ2dsZSgnb3BlbicpfVxuXG5mdW5jdGlvbiBtZW51Q2xvc2U5KCkge1xuICAgIG1lbnUuY2xhc3NMaXN0LnJlbW92ZSgnb3BlbicpO1xufVxuZnVuY3Rpb24gbWVudUNsb3NlKCkge1xuICAgIGxhbmdfc2VsZWN0LmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTtcbn1cbmZ1bmN0aW9uIG1lbnVDbG9zZUNsaWNrT3V0c2lkZTkoZSkge1xuICAgIGlmKCFlLnRhcmdldC5tYXRjaGVzKCcuYnVyZ2VyIConKSl7XG4gICAgICAgIG1lbnVDbG9zZTkoKTtcbiAgICB9XG59XG5mdW5jdGlvbiBtZW51Q2xvc2VDbGlja091dHNpZGUoZSkge1xuICAgIGlmKCFlLnRhcmdldC5tYXRjaGVzKCcubGFuZ3VhZ2Utc2VsZWN0IConKSl7XG4gICAgICAgIG1lbnVDbG9zZSgpO1xuICAgIH1cbn1cbmRvYy5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIG1lbnVDbG9zZUNsaWNrT3V0c2lkZTkpO1xuZG9jLmFkZEV2ZW50TGlzdGVuZXIoJ3RvdWNoc3RhcnQnLCBtZW51Q2xvc2VDbGlja091dHNpZGU5KTtcbmRvYy5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIG1lbnVDbG9zZUNsaWNrT3V0c2lkZSk7XG5kb2MuYWRkRXZlbnRMaXN0ZW5lcigndG91Y2hzdGFydCcsIG1lbnVDbG9zZUNsaWNrT3V0c2lkZSk7Il0sImZpbGUiOiI0MDQuanMifQ==
