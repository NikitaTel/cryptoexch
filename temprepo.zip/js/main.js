var
    doc = document,
    win = window,
    body = doc.getElementById('body'),
    menu = doc.getElementsByClassName('burger')[0],
    lang_select = doc.getElementsByClassName('language-select')[0],
    contact_switcher = doc.getElementsByClassName('lk-contact_switcher_label')[0],
    accounts_switcher = doc.getElementsByClassName('your-accounts_switcher_label')[0],
    df_left = doc.getElementsByClassName('doble-form_left')[0],
    df_right = doc.getElementsByClassName('doble-form_right')[0],
    df_left2 = doc.getElementById('df_left2'),
    df_right2 = doc.getElementById('df_right2'),
    df_left3 = doc.getElementById('df_left3'),
    df_right3 = doc.getElementById('df_right3'),
    button_up = doc.getElementsByClassName('button_up')[0];

// Lang Menu Open/Close
function menuToggle() {
    lang_select.classList.toggle('open');
}
// Shit 228
function menuToggle4() {
    df_left.classList.toggle('open')
}

function menuToggle5() {
    df_right.classList.toggle('open')
}

function menuToggle6() {
    df_left2.classList.toggle('open')
}

function menuToggle7() {
    df_right2.classList.toggle('open')
}

function menuToggle8() {
    df_left3.classList.toggle('open')
}

function menuToggle9() {
    df_right3.classList.toggle('open')
}

function menuToggle10() {
    menu.classList.toggle('open')
}

function menuClose10() {
    menu.classList.remove('open');
}

function menuCloseClickOutside10(e) {
    if (!e.target.matches('.burger *')) {
        menuClose10();
    }
}

function menuToggle2() {
    accounts_switcher.classList.toggle('open')
}

function menuToggle3() {
    contact_switcher.classList.toggle('open')
}

function menuClose() {
    lang_select.classList.remove('open');
}

function menuClose2() {
    accounts_switcher.classList.remove('open');
}

function menuClose3() {
    contact_switcher.classList.remove('open');
}

// Lang Menu Close Click Outside
doc.addEventListener('click', menuCloseClickOutside);
doc.addEventListener('touchstart', menuCloseClickOutside);

doc.addEventListener('click', menuCloseClickOutside10);
doc.addEventListener('touchstart', menuCloseClickOutside10);

/***************
 * @Smooth Scrolling
 ***************/
var links = doc.querySelectorAll("[href^='#']");
for (var i = 0; i < links.length; i++) {
    links[i].addEventListener('click', function (event) {
        event.preventDefault();

        // Get id and scrollIt
        var id = this.getAttribute('href');
        scrollIt(doc.querySelector(id));
    });
}
/***** @End *****/


/** @Button Up **/
function scrollFunctions() {
    var
        pageY = win.pageYOffset;

    if (pageY > 250) {
        button_up.classList.add('fixed');
    } else {
        button_up.classList.remove('fixed');
    }
}
win.addEventListener('scroll', function () {
    scrollFunctions();
});
win.addEventListener('load', function () {
    scrollFunctions();
    $("#blockexchange").hide(); //block exchange hide by default
    //setTime('13:10:04')
});
/***** @End *****/

//block exchange timer


function setTime(time) { //вставить время в таймер
    $arr = doc.getElementsByClassName("timer-digit"); //select 6 spans of digits
    $i = 0;
    $TC = 0;
    for ($i; $i <= time.length - 1; $i++) {
        if (isNumeric(time[$i]) && $TC <= 5) { //filling 
            $arr[$TC].innerHTML = time[$i];
            $TC++;
        }

    }
}

function isNumeric(str) {
    if (typeof str != "string") return false // we only process strings!  
    return !isNaN(str) && // use type coercion to parse the _entirety_ of the string (`parseFloat` alone does not do this)...
        !isNaN(parseFloat(str)) // ...and ensure strings of whitespace fail
}
//block exchange timer

//feedback stars
function star(q,parent) {
    $arr = $(parent).find('.current');
    $i = 0;
    for ($i; $i <= q - 1; $i++) {

        $arr[$i].className = "i-star current active";

    }
    $i = q;
    for ($i; $i <= $arr.length-1; $i++) {

        $arr[$i].className = "i-star current";

    }
}
//feedback stars

//questions accordion
function accordion(el) {

    if (!$(el).find(".accordion-content-active").length) { //если не тыкнули по итак открытому элементу
        $(".accordion-content-active").hide(300); //убрать все открытые
        setTimeout(function () { //таймер выждать пока уберется
            $(".accordion-content-active").addClass("accordion-content"); //добавить обычный класс
            $(".accordion-content-active").removeClass("accordion-content-active"); //убрать класс открытый
        }, 300);
        $(".arrow").css("transform", "none"); //все стрелки в исходное положение
        $(el).find(".accordion-content").fadeIn(500); //найти дитя контент в выбранном элементе и показать
        setTimeout(function () {
            $(el).find(".accordion-content").addClass("accordion-content-active"); //добавить класс открыто
            $(el).find(".accordion-content-active").removeClass("accordion-content"); //убрать класс закрыто
        }, 300);
        $(el).find(".arrow").css("transform", "rotate(180deg)"); //поворот стрелки
    } else {
        $(el).find(".accordion-content-active").hide(300); //если тыкнули по уже открытому аккордиону, спрятать его, обход повторного открытия его же
        $(".arrow").css("transform", "none"); //стрелку в исходное
        $(el).find(".accordion-content-active").addClass("accordion-content"); //классы тут же на место
        $(el).find(".accordion-content-active").removeClass("accordion-content-active");

    }
}
//questions accordion
//help messages

setTimeout(function () {
    try{
    $("#helpMsgLeft").fadeOut(700);
    $("#helpMsgRight").fadeOut(700);
    }
    catch{

    }
}, 3000)


//help messages

// check fields & erroring fields
function wrongField(el, release) {
    if (!release) {
        $(el).addClass('wrong-field')
    } else {
        try {
            $(el).removeClass('wrong-field');
        } catch {

        }
    }
}

function checkFields(el) {
    $arr = $(el.toString() + " :input");
    $i = 0;
    for ($i; $i <= $arr.length - 1; $i++) {
        if (($($arr[$i]).prop("type") != 'hidden')) {

            if ($($arr[$i]).is(":invalid")) {
                wrongField($arr[$i], false);
            } else {
                wrongField($arr[$i], true);
            }

        }
    }
}
// check fields & erroring fields
function handleReg() {
    checkFields('.registration-new');
    if ($('.registration-new .wrong-field').length == 0) {
        document.getElementById('registr').checked = false;
        document.getElementById('registr-step3').checked = true;
    } else {
        $('.registration-new .error').html("Введены не все данные или капча");
    }

}

function checkpass(el, el2) {
    checkFields('.registration-s3');
    if ($(el).val() != $(el2).val()) {
        wrongField(el);
        wrongField(el2);
        $('.registration-s3 .error').html('Пароли не совпадают');
        return false;
    } else {

        return true;
    }
}

function handleRegPass() {

    if ($('.registration-s3 .wrong-field').length == 0 && checkpass()) {
        document.getElementById('registr-step3').checked = false;
        document.getElementById('registr-step2').checked = true;
        $('.registration-s3 .error').html('');
    } else {
        $('.registration-s3 .error').html('Пароли не совпадают');
    }


}
$('.MoneyOut').click(function(){
    $('#moneyOut').show();
});
$('.Subscribe').click(function(){
    $('.Subscribe').parents('div').last().hide();
    $('#thanksSubs').show();
});
$('.feedLeave').click(function(){
    //$('.feedLeave').parents('div').last().hide();
    $('#thanksFeed').show();
});